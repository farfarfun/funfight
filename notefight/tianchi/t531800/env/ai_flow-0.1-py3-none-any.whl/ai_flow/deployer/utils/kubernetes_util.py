from typing import Text
from kubernetes import config

kubernetes_cluster_available = False


def load_kubernetes_config(config_file_path: Text = None):
    global kubernetes_cluster_available
    if config_file_path is not None:
        # load kubernetes config from user provided config file
        config.load_kube_config(config_file=config_file_path)
        kubernetes_cluster_available = True
    else:
        try:
            # load local kubernetes config
            config.load_kube_config()
            kubernetes_cluster_available = True
        except Exception as e:
            try:
                config.load_incluster_config()
                kubernetes_cluster_available = True
            except Exception as e:
                pass
