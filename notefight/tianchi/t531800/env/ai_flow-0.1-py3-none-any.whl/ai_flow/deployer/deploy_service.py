from ai_flow.rest_endpoint.protobuf.deploy_service_pb2_grpc import DeployServiceServicer
from ai_flow.rest_endpoint.protobuf.deploy_service_pb2 import ScheduleResponse, WorkflowRequest
from ai_flow.rest_endpoint.service.client.aiflow_client import _SERVER_URI
from ai_flow.deployer.scheduler import SchedulerManager
from ai_flow.workflow.workflow import Workflow
from ai_flow.common.json_utils import loads


class DeployService(DeployServiceServicer):

    def __init__(self, server_uri=_SERVER_URI):
        self.scheduler_manager = SchedulerManager(server_uri=server_uri)

    def startScheduleWorkflow(self, request, context):
        try:
            rq: WorkflowRequest = request
            workflow_json = rq.workflow_json
            workflow: Workflow = loads(workflow_json)
            workflow_id = self.scheduler_manager.schedule_workflow(workflow=workflow)
            return ScheduleResponse(return_code=0, return_msg='', data=str(workflow_id))
        except Exception as err:
            print(err.args)
            return ScheduleResponse(return_code=1, return_msg=str(err), data='0')

    def stopScheduleWorkflow(self, request, context):
        try:
            rq: WorkflowRequest = request
            workflow_id = rq.id
            self.scheduler_manager.stop_schedule_workflow(workflow_id=workflow_id)
            return ScheduleResponse(return_code=0, return_msg='', data=str(workflow_id))
        except Exception as err:
            return ScheduleResponse(return_code=1, return_msg=str(err), data='0')

    def getWorkflowExecutionResult(self, request, context):
        try:
            rq: WorkflowRequest = request
            workflow_id = rq.id
            res = self.scheduler_manager.get_schedule_result(workflow_id=workflow_id)
            if res is None:
                res = 0
            return ScheduleResponse(return_code=0, return_msg='', data=str(res))
        except Exception as err:
            return ScheduleResponse(return_code=1, return_msg=str(err), data='0')

    def isWorkflowExecutionAlive(self, request, context):
        try:
            rq: WorkflowRequest = request
            workflow_id = rq.id
            res = self.scheduler_manager.workflow_is_alive(workflow_id=workflow_id)
            if res is None:
                return ScheduleResponse(return_code=1,
                                        return_msg='no such workflow execution: {}'.format(workflow_id), data='')
            else:
                return ScheduleResponse(return_code=0, return_msg='', data=str(res))
        except Exception as err:
            return ScheduleResponse(return_code=1, return_msg=str(err), data=str(False))

    def start_scheduler_manager(self):
        self.scheduler_manager.start()

    def stop_scheduler_manager(self):
        self.scheduler_manager.stop()
