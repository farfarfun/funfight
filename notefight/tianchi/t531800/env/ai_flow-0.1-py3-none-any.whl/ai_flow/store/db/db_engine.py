"""
List of SQLAlchemy database engines for Rest Endpoint of AIFlow backend storage.
"""

MYSQL = 'mysql'
SQLITE = 'sqlite'
POSTGRES = 'postgresql'
MSSQL = 'mssql'

DATABASE_ENGINES = [
    MYSQL,
    SQLITE,
    POSTGRES,
    MSSQL,
]
