from sqlalchemy import BigInteger
from sqlalchemy import Column
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.ext.declarative import declarative_base

base = declarative_base()


@compiles(BigInteger, 'sqlite')
def bi_c(element, compiler, **kw):
    return "INTEGER"


class Base:
    __table_args__ = {'sqlite_autoincrement': True}

    """
    Column uuid is SQL model primary key, auto increment, which type is BigInteger, but Integer for SQLite.
    """
    uuid = Column(BigInteger, primary_key=True, autoincrement=True)
