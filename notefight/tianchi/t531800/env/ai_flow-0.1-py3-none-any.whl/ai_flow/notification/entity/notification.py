from ai_flow.common.entity import Entity
from ai_flow.rest_endpoint.protobuf.message_pb2 import Notification as ProtoNotification
from ai_flow.rest_endpoint.service import stringValue, int32Value


class Notification(Entity):
    """
    AIFlow entity for Notification Detailed. Provides notification metadata in addition to information in Notification Service.
    """

    def __init__(self, key, value=None, version=None):
        # Constructor is called only from within the system by various backend stores.
        super(Notification, self).__init__()
        self._key = key
        self._value = value
        self._version = version

    @property
    def key(self):
        """String. Notification key."""
        return self._key

    @property
    def value(self):
        """String. Notification value."""
        return self._value

    @property
    def version(self):
        """Integer. Notification version."""
        return self._version

    # proto mappers
    @classmethod
    def from_proto(cls, proto):
        notification = proto
        return cls(notification.key.value if notification.HasField("key") else None,
                   notification.value.value if notification.HasField("value") else None,
                   notification.version.value if notification.HasField("version") else None)

    @classmethod
    def from_req_proto(cls, proto):
        notification = proto.notification
        return cls(notification.key.value if notification.HasField("key") else None,
                   notification.value.value if notification.HasField("value") else None,
                   notification.version.value if notification.HasField("version") else None)

    def to_proto(self):
        return ProtoNotification(key=stringValue(self.key), value=stringValue(self.value),
                                 version=int32Value(self.version))
