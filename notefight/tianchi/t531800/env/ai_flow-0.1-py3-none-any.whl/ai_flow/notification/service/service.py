import asyncio
import time

from ai_flow.notification.entity.notification import Notification
from ai_flow.rest_endpoint.protobuf import notification_service_pb2_grpc
from ai_flow.rest_endpoint.protobuf.message_pb2 import Notifications
from ai_flow.rest_endpoint.service.util import catch_exception, _wrap_response
from ai_flow.store.sqlalchemy_store import SqlAlchemyStore


class NotificationService(notification_service_pb2_grpc.NotificationServiceServicer):

    def __init__(self, backend_store_uri):
        self.notification_store = SqlAlchemyStore(backend_store_uri)
        self.notification_conditions = {}
        self.lock = asyncio.Lock()

    @catch_exception
    @asyncio.coroutine
    def updateNotification(self, request, context):
        return self._update_notification(request)

    async def _update_notification(self, request):
        notification_param = Notification.from_req_proto(request)
        key = notification_param.key
        # Lock conditions dict for get/check/update of key
        await self.lock.acquire()
        if self.notification_conditions.get(key) is None:
            self.notification_conditions.update({(key, asyncio.Condition())})
        # Release lock after check/update key of notification conditions dict
        self.lock.release()
        async with self.notification_conditions.get(key):
            notification_meta = self.notification_store.create_notification(key, notification_param.value)
            self.notification_conditions.get(key).notify_all()
        return _wrap_response(notification_meta.to_proto())

    @catch_exception
    @asyncio.coroutine
    def listNotifications(self, request, context):
        return self._list_notifications(request)

    async def _list_notifications(self, request):
        notification_param = Notification.from_req_proto(request)
        key = notification_param.key
        version = notification_param.version
        timeout_seconds = request.timeout_seconds

        if timeout_seconds == 0:
            notifications = self._query_notifications(key, version)
            return _wrap_response(
                Notifications(notifications=[notification.to_proto() for notification in notifications]))
        else:
            start = time.time()
            # Lock conditions dict for get/check/update of key
            await self.lock.acquire()
            if self.notification_conditions.get(key) is None:
                self.notification_conditions.update({(key, asyncio.Condition())})
            # Release lock after check/update key of notification conditions dict
            self.lock.release()
            notifications = self._query_notifications(key, version)
            async with self.notification_conditions.get(key):
                while time.time() - start < timeout_seconds and len(notifications) == 0:
                    try:
                        await asyncio.wait_for(self.notification_conditions.get(key).wait(),
                                               timeout_seconds - time.time() + start)
                        notifications = self._query_notifications(key, version)
                    except asyncio.TimeoutError:
                        pass
            return _wrap_response(
                Notifications(notifications=[notification.to_proto() for notification in notifications]))

    def _query_notifications(self, key, version):
        return self.notification_store.list_notifications(Notification(key=key, version=version))
