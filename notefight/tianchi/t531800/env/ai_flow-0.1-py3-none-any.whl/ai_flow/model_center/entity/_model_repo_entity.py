from abc import abstractmethod

from ai_flow.model_center.entity._model_repo_object import _ModelRepoObject


class _ModelRepoEntity(_ModelRepoObject):

    @classmethod
    @abstractmethod
    def from_proto(cls, proto):
        pass

    def __eq__(self, other):
        return dict(self) == dict(other)
