"""
The ``aiflow.sklearn`` module provides an API for loading scikit-learn models.
"""

from __future__ import absolute_import

import pickle


def _load_model_from_local_file(path):
    """Load a scikit-learn model saved as an aiflow artifact on the local file system."""
    with open(path, "rb") as f:
        return pickle.load(f)


def load_model(model_uri):
    """
    Load a scikit-learn model from a local file.

    :param model_uri: The location, in URI format, of the aiflow model, for example:

                      - ``/Users/aiflow/path/to/local/model``
                      - ``relative/path/to/local/model``
                      - ``s3://my_bucket/path/to/model``
                      - ``models:/<model_name>/<model_version>``
                      - ``models:/<model_name>/<stage>``

    :return: A scikit-learn model.
    """
    return _load_model_from_local_file(path=model_uri)
