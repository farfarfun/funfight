import queue


class MessageQueue(object):

    def __init__(self) -> None:
        self.queue = queue.Queue()

    def send(self, event):
        self.queue.put_nowait(event)

    def get(self):
        return self.queue.get()

    def length(self):
        return self.queue.qsize()

    def get_with_timeout(self, timeout=1):
        try:
            return self.queue.get(timeout=timeout)
        except Exception as e:
            return None
