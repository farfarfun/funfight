import yaml
from typing import Dict, Text


class AIFlowConfiguration(Dict[Text, Text]):

    def load_from_file(self, file_path):
        with open(file_path, 'r') as f:
            yaml_config = yaml.load(f)
            self.update(yaml_config.items())

    def dump_to_file(self, file_path):
        with open(file_path, 'w') as f:
            return yaml.dump(data=self, stream=f)
