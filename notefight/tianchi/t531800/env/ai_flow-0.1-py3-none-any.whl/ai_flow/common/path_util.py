import os


def get_file_dir(file):
    return os.path.dirname(os.path.abspath(file))


def get_parent_dir(path):
    return os.path.dirname(path)


def get_module_name(main_file):
    return os.path.basename(main_file)[:-3]
