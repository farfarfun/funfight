import yaml
from typing import Dict


def load_yaml_file(file_path) -> Dict:
    with open(file_path, 'r') as f:
        return yaml.load(f)


def dump_yaml_file(data: Dict, file_path):
    with open(file_path, 'w') as f:
        return yaml.dump(data=data, stream=f, sort_keys=True)
