from ai_flow.api.configuration import _default_project_config, ensure_project_registered
from ai_flow.rest_endpoint.service.client.aiflow_client import AIFlowClient


_default_ai_flow_client = None
_default_master_uri = 'localhost:50051'


def get_ai_flow_client():

    """ Get AI flow Client. """

    global _default_ai_flow_client, _default_master_uri
    ensure_project_registered()
    if _default_ai_flow_client is None:
        current_uri = _default_project_config.get_master_uri()
        if current_uri is None:
            return None
        else:
            _default_master_uri = current_uri
            _default_ai_flow_client = AIFlowClient(server_uri=_default_master_uri)
            return _default_ai_flow_client
    else:
        current_uri = _default_project_config.get_master_uri()
        if current_uri != _default_master_uri:
            _default_master_uri = current_uri
            _default_ai_flow_client = AIFlowClient(server_uri=_default_master_uri)

        return _default_ai_flow_client

