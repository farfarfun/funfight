import json
import os
import time
from subprocess import Popen, PIPE, STDOUT
from typing import List

import requests
import yaml

from ai_flow.api.notification import start_listen_notification, stop_listen_notification
from ai_flow.rest_endpoint.service.client.notification_client import Watcher
from ai_flow.udf.function_context import FunctionContext
from python_ai_flow import Executor


class ServingWatcher(Watcher):

    def __init__(self):
        super().__init__()
        self.model_version = None

    def process(self, listener_name, notifications):
        for notification in notifications:
            self.model_version = notification.value


class ServingExecutor(Executor):
    def __init__(self, parallelism):
        super().__init__()
        self._watcher = ServingWatcher()
        self._parallelism = parallelism

    def setup(self, function_context: FunctionContext):
        # Start to listen notification from training model.
        start_listen_notification(listener_name='serving_listener', key=function_context.node_spec.model.name,
                                  watcher=self._watcher)

    def execute(self, function_context: FunctionContext, input_list: List) -> List:
        while self._watcher.model_version is None:
            time.sleep(5)
        self.cluster_serving()
        return []

    def close(self, function_context: FunctionContext):
        # Stop to listen notification from training model.
        stop_listen_notification(listener_name='serving_listener', key=function_context.node_spec.model.name, )

    def cluster_serving(self):
        rest_host = os.environ.get('REST_HOST') if 'REST_HOST' in os.environ else 'localhost'
        rest_port = int(os.environ.get('REST_PORT')) if 'REST_PORT' in os.environ else 8081
        cluster_serving_path = os.environ.get(
            'CLUSTER_SERVING_PATH') if 'CLUSTER_SERVING_PATH' in os.environ else '/tmp/cluster-serving'
        serving_job_path = os.environ.get(
            'SERVING_JOB_PATH') if 'SERVING_JOB_PATH' in os.environ else '/tmp/cluster-serving-job-id'
        serving_http_path = os.environ.get(
            'SERVING_HTTP_PATH') if 'SERVING_HTTP_PATH' in os.environ else '/root/Applications/cluster-serving/analytics-zoo-bigdl_0.10.0-spark_2.4.3-0.9.0-SNAPSHOT-http.jar'
        print('Cluster serving path: %s.' % cluster_serving_path)
        if os.path.exists(cluster_serving_path):
            # Stop cluster serving if running.
            process = Popen('ps -ef | grep "SNAPSHOT-http" | grep -v grep | awk \'{print $2}\'', shell=True,
                            stdout=PIPE, stderr=STDOUT)
            output = process.communicate()[0]
            for pid in str(output, encoding='utf8').split('\n'):
                print(pid)
                if pid != '':
                    Popen('kill -9 {}'.format(pid), shell=True)
            Popen('rm -rf /tmp/debug.txt', shell=True)
            Popen('cd %s;cluster-serving-stop' % cluster_serving_path,
                  shell=True)
            Popen('redis-cli flushall', shell=True)
            print('Stop cluster serving.')
            if os.path.exists(serving_job_path):
                requests.patch('http://%s:%d/jobs/%s' % (rest_host, rest_port, self.get_job_id(serving_job_path)))
                os.remove(serving_job_path)
        else:
            os.makedirs(cluster_serving_path, exist_ok=True)
            # Initialize cluster serving.
            Popen('cd %s;cluster-serving-init' % cluster_serving_path, shell=True)
            print('Initialize cluster serving.')
            while not os.path.exists(cluster_serving_path + '/config.yaml'):
                time.sleep(1)
        # Yaml dump model path config.
        with open(cluster_serving_path + '/config.yaml', 'w') as f:
            yaml.dump({'model': {'path': json.loads(self._watcher.model_version).get('_model_path')}}, f)
        # Start cluster serving to load trained model.
        Popen('java -jar %s >>/tmp/debug.txt &' % serving_http_path, shell=True)
        Popen(
            'cd %s;cluster-serving-start --parallelism %d --config_path %s/config.yaml' % (
                cluster_serving_path, self._parallelism, cluster_serving_path), shell=True)
        print('Start cluster serving.')
        while not os.path.exists(serving_job_path):
            time.sleep(1)
        # Check whether cluster serving starts successfully to validate the status of loading model.
        response = requests.get('http://%s:%d/jobs/%s' % (rest_host, rest_port, self.get_job_id(serving_job_path)))
        if response.status_code == 200:
            print('Whether cluster serving has already loaded model is: ' + str(
                json.loads(response.text).get('state') == 'RUNNING'))

    @staticmethod
    def get_job_id(serving_job_path: str):
        with open(serving_job_path) as f:
            job_id = f.readline()
            return job_id
