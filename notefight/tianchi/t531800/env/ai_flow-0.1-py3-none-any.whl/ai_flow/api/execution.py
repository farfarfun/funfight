_workflow_execution_id_set_flag = False
_workflow_execution_id = None


def set_workflow_execution_id(workflow_execution_id: int):
    global _workflow_execution_id_set_flag
    if _workflow_execution_id_set_flag:
        raise Exception("project configuration cannot be set repeatedly!")
    else:
        _workflow_execution_id = workflow_execution_id
        _workflow_execution_id_set_flag = True


def get_workflow_execution_id():
    return _workflow_execution_id
