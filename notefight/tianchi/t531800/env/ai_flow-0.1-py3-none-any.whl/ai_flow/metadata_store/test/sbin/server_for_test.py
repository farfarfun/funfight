import os
import sys
import tempfile

sys.path.append(os.path.abspath(os.path.join(os.getcwd(), "../../../..")))

from ai_flow.rest_endpoint.service.server import AIFlowServer

if __name__ == '__main__':
    fd, temp_dbfile = tempfile.mkstemp()
    os.close(fd)
    db_uri = '%s%s' % ('sqlite:///', temp_dbfile)
    server = AIFlowServer(store_uri=db_uri)
    server.run(is_block=True)
