from typing import List, Dict, Text
from ai_flow.graph.node import BaseNode
from ai_flow.graph.edge import JobControlEdge
from ai_flow.workflow.job import BaseJob
from ai_flow.graph.graph import _get_id_generator
from ai_flow.project.project_description import ProjectDesc


class Workflow(BaseNode):

    def __init__(self) -> None:
        super().__init__()
        self.workflow_id: int = None
        self.execution_name: Text = None
        self.jobs: Dict[Text, BaseJob] = {}
        self.edges: Dict[Text, List[JobControlEdge]] = {}
        self.workflow_phase = None
        self.start_time = None
        self.end_time = None
        self.project_desc: ProjectDesc = None

    def add_job(self, job: BaseJob):
        if job.instance_id is None:
            instance_id = _get_id_generator(self).generate_id(job)
            job.set_instance_id(instance_id)
        self.jobs[job.instance_id] = job

    def add_edges(self, job_instance_id: Text, dependencies: List[JobControlEdge]):
        self.edges[job_instance_id] = dependencies

    def add_edge(self, job_instance_id: Text, edge: JobControlEdge):
        if job_instance_id not in self.edges:
            self.edges[job_instance_id] = []
        self.edges[job_instance_id].append(edge)

