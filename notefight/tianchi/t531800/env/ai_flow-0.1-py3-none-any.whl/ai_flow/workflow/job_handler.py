from typing import Text, Any


class BaseJobHandler(object):
    def __init__(self, job_instance_id: Text, job_uuid: int, workflow_id: int) -> None:
        self.job_instance_id: Text = job_instance_id
        self.job_uuid: int = job_uuid
        self.workflow_id: int = workflow_id
        self.platform = None

