from enum import Enum


class LanguageType(str, Enum):
    PYTHON = "PYTHON"
    JAVA = "JAVA"
