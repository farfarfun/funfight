from ai_flow.plugins.job_plugin import register_job_plugin
from ai_flow.plugins.platform import register_platform
from ai_flow.plugins.local_platform import LocalPlatform
from ai_flow.plugins.kubernetes_platform import KubernetesPlatform
from ai_flow.plugins.local_cmd_job_plugin import LocalCMDJobPlugin
from ai_flow.plugins.kubernetes_cmd_job_plugin import KubernetesCMDJobPlugin


register_platform(LocalPlatform)
register_platform(KubernetesPlatform)

register_job_plugin(LocalCMDJobPlugin())
register_job_plugin(KubernetesCMDJobPlugin())

