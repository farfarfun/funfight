import os
from abc import ABC, abstractmethod
from typing import Dict, Text
from kubernetes import client
from ai_flow.plugins.platform import AbstractPlatform
from ai_flow.workflow.job_context import JobContext

from ai_flow.plugins.kubernetes_platform import KubernetesPlatform, KubernetesJobHandler, DEFAULT_NAMESPACE, \
    DEFAULT_PROJECT_PATH

from ai_flow.plugins.job_plugin import AbstractJobConfig, AbstractJob, AbstractJobPlugin


class KubernetesJobConfig(AbstractJobConfig):
    @staticmethod
    def from_dict(data: Dict, config) -> object:
        return AbstractJobConfig.from_dict(data, config)

    def __init__(self, engine: Text):
        super().__init__(platform=KubernetesPlatform.platform(), engine=engine)


class KubernetesJob(AbstractJob):
    def __init__(self,
                 job_context: JobContext = JobContext(),
                 job_config: AbstractJobConfig = KubernetesJobConfig):
        super().__init__(job_context, job_config)
        self.k8s_job_handler = None


class KubernetesJobPlugin(AbstractJobPlugin, ABC):

    def __init__(self) -> None:
        super().__init__()
        self.job_handler_map: Dict[Text, KubernetesJobHandler] = {}

    def platform(self) -> type(AbstractPlatform):
        return KubernetesPlatform

    def submit_job(self, job: KubernetesJob) -> KubernetesJobHandler:
        if job.k8s_job_handler is None:
            job.k8s_job_handler = self.create_k8s_job(job)

        batchV1 = client.BatchV1Api()
        batchV1.create_namespaced_job(namespace=DEFAULT_NAMESPACE, body=job.k8s_job_handler)
        print("create k8s job {}".format(job.job_name))
        job_handler = KubernetesJobHandler(job_instance_id=job.instance_id,
                                           job_uuid=job.uuid,
                                           workflow_id=job.job_context.workflow_execution_id)
        return job_handler

    def stop_job(self, job: KubernetesJob):
        self.cleanup_job(job)

    def cleanup_job(self, job: KubernetesJob):
        if job.k8s_job_handler is None:
            return
        if job.job_config.is_clean_job_resource():
            batchV1 = client.BatchV1Api()
            response = batchV1.delete_namespaced_job(namespace=DEFAULT_NAMESPACE,
                                                     name=job.k8s_job_handler.metadata.name,
                                                     body=client.V1DeleteOptions(
                                                         propagation_policy='Foreground',
                                                         grace_period_seconds=5))
            job.k8s_job_handler = None

        if job.uuid in self.job_handler_map:
            del self.job_handler_map[job.uuid]

    @abstractmethod
    def create_k8s_job(self, job: KubernetesJob)->client.V1Job:
        pass

    @staticmethod
    def create_init_container(job: AbstractJob, volume_mount, job_container)->client.V1PodSpec:
        from ai_flow.application_master.master import GLOBAL_MASTER_CONFIG
        print('Kubernetes GLOBAL_MASTER_CONFIG {}'.format(GLOBAL_MASTER_CONFIG))
        init_args_default = [str(job.job_config.project_desc.project_config),
                             str(job.job_context.workflow_execution_id),
                             job.job_config.project_path,
                             DEFAULT_PROJECT_PATH]
        init_container \
            = client.V1Container(name='init-container',
                                 image=GLOBAL_MASTER_CONFIG['ai_flow_base_init_image'],
                                 image_pull_policy='Always',
                                 command=["python", "/app/download.py"],
                                 args=init_args_default, volume_mounts=[volume_mount])
        volume = client.V1Volume(name='download-volume')
        pod_spec = client.V1PodSpec(restart_policy='Never', containers=[job_container],
                                    init_containers=[init_container],
                                    volumes=[volume])
        return pod_spec

    @staticmethod
    def get_container_working_dir(job: AbstractJob)->Text:
        project_dir_name = 'workflow_{}_project'.format(job.job_context.workflow_execution_id)
        user_project_dir_name = os.path.basename(job.job_config.project_desc.project_path)
        working_dir = "{}/{}/{}".format(DEFAULT_PROJECT_PATH, project_dir_name, user_project_dir_name)
        print("working_dir {}".format(working_dir))
        return working_dir
