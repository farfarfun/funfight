from typing import Text
from ai_flow.common.json_utils import Jsonable


class AbstractEngine(Jsonable):
    """
    ai flow job must run by one engine, such as python bash etc.
    """

    def __init__(self) -> None:
        super().__init__()

    @staticmethod
    def engine() -> Text:
        """
        :return platform name:
        """
        raise NotImplementedError("not implement engine")


class CMDEngine(AbstractEngine):
    @staticmethod
    def engine() -> Text:
        return 'cmd_line'
