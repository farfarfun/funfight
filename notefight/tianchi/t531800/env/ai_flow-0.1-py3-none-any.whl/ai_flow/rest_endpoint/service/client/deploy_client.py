from typing import Text, Tuple
import grpc
from ai_flow.rest_endpoint.protobuf import deploy_service_pb2, deploy_service_pb2_grpc
from ai_flow.common.bool_util import str_to_bool
from ai_flow.rest_endpoint.service.client.base_client import BaseClient


class DeployClient(BaseClient):
    def __init__(self, server_uri):
        super(DeployClient, self).__init__(server_uri)
        channel = grpc.insecure_channel(server_uri)
        self.deploy_stub = deploy_service_pb2_grpc.DeployServiceStub(channel)

    def submit_workflow(self, workflow: Text) -> Tuple[int, int, Text]:
        """
        submit ExecutableWorkflow to DeployService
        :param workflow: workflow json
        :return: return_code, workflow_id, message
        """
        request = deploy_service_pb2.WorkflowRequest(id=0, workflow_json=workflow)
        response = self.deploy_stub.startScheduleWorkflow(request)
        return response.return_code, int(response.data), str(response.return_msg)

    def stop_workflow(self, workflow_id: int) -> Tuple[int, int, Text]:
        """
        stop WorkflowExecution
        :param workflow_id: WorkflowExecution uuid
        :return: return_code, workflow_id, message
        """
        request = deploy_service_pb2.WorkflowRequest(id=workflow_id, workflow_json='')
        response = self.deploy_stub.stopScheduleWorkflow(request)
        return response.return_code, int(response.data), str(response.return_msg)

    def get_workflow_execution_result(self, workflow_id: int) -> Tuple[int, int, Text]:
        """
        stop WorkflowExecution
        :param workflow_id: WorkflowExecution uuid
        :return: return_code, schedule result, message
        """
        request = deploy_service_pb2.WorkflowRequest(id=workflow_id, workflow_json='')
        response = self.deploy_stub.getWorkflowExecutionResult(request)
        return response.return_code, int(response.data), str(response.return_msg)

    def is_alive_workflow(self, workflow_id: int) -> Tuple[int, int, Text]:
        """
        stop WorkflowExecution
        :param workflow_id: WorkflowExecution uuid
        :return: return_code, workflow_id, message
        """
        request = deploy_service_pb2.WorkflowRequest(id=workflow_id, workflow_json='')
        response = self.deploy_stub.isWorkflowExecutionAlive(request)
        # print(response.return_code, str(response.data), str(response.return_msg))
        return response.return_code, str_to_bool(str(response.data)), str(response.return_msg)
