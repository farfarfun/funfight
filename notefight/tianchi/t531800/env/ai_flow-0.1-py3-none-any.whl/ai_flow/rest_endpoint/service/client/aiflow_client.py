from ai_flow.rest_endpoint.service.client.deploy_client import DeployClient
from ai_flow.rest_endpoint.service.client.metadata_client import MetadataClient
from ai_flow.rest_endpoint.service.client.model_center_client import ModelCenterClient
from ai_flow.rest_endpoint.service.client.notification_client import NotificationClient
from ai_flow.rest_endpoint.service.client.metric_client import MetricClient


_SERVER_URI = 'localhost:50051'


class AIFlowClient(MetadataClient, ModelCenterClient, NotificationClient, DeployClient, MetricClient):
    """
    Client of an AIFlow Server that manages metadata store, model center and notification service.
    """

    def __init__(self, server_uri=_SERVER_URI):
        super(AIFlowClient, self).__init__(server_uri)
