from google.protobuf.wrappers_pb2 import StringValue, Int32Value, Int64Value


def stringValue(field):
    if field is None:
        return None
    else:
        return StringValue(value=field)


def int32Value(field):
    if field is None:
        return None
    else:
        return Int32Value(value=field)


def int64Value(field):
    if field is None:
        return None
    else:
        return Int64Value(value=field)
