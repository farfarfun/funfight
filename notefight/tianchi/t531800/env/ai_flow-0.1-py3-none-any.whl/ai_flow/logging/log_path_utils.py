from typing import Text


def stdout_log_path(log_path, job_name) -> Text:
    return "{}/{}_stdout.log".format(log_path, job_name)


def stderr_log_path(log_path, job_name) -> Text:
    return "{}/{}_stderr.log".format(log_path, job_name)
