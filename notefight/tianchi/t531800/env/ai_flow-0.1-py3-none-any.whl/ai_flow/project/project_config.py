from ai_flow.common.configuration import AIFlowConfiguration


class ProjectConfig(AIFlowConfiguration):
    def get_master_ip(self):
        return self["master_ip"]

    def set_master_ip(self, value):
        self["master_ip"] = value

    def get_master_port(self):
        return self["master_port"]

    def set_master_port(self, value):
        self["master_port"] = value

    def get_master_uri(self):
        return "{}:{}".format(self["master_ip"], self["master_port"])

    def get_project_name(self):
        return self["project_name"]

    def set_project_name(self, value):
        self["project_name"] = value

    def get_project_uuid(self):
        return self["project_uuid"]

    def set_project_uuid(self, value):
        self["project_uuid"] = value


_default_project_config = ProjectConfig()
