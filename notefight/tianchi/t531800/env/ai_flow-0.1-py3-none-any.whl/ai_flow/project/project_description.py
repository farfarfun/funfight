import os
from typing import List, Text
from ai_flow.project.project_config import ProjectConfig, _default_project_config
from ai_flow.common.json_utils import Jsonable
from pathlib import Path


class ProjectDesc(Jsonable):
    """
    ProjectDesc( project descriptor) maintains the directory structure and information of an ai flow project.
    A common ai flow project would follow the directory structure as bellow.

    SimpleProject
    ├─ project.yaml
    ├─ jar_dependencies
    ├─ resource
    ├─ temp
    ├─ logs
    └─ python_codes
       ├─ __init__.py
       ├─ my_ai_flow.py
       └─ requirements.txt
    """
    def __init__(self) -> None:
        super().__init__()
        self.project_name: Text = None
        self.project_path = '/tmp'
        self.python_dependencies: List[Text] = []
        self.jar_dependencies: List[Text] = []
        self.resources: List[Text] = []
        self.project_temp_path: Text = 'temp'
        self.log_path: Text = "logs"
        self.project_config: ProjectConfig = _default_project_config
        self.python_paths: List[Text] = []

    def get_absolute_temp_path(self)->Text:
        return "{}/{}".format(self.project_path, self.project_temp_path)

    def get_absolute_log_path(self)->Text:
        return "{}/{}".format(self.project_path, self.log_path)


_default_project_Desc = ProjectDesc()


def get_project_description_from(project_path: Text) -> ProjectDesc:
    """
    Load a project descriptor for a given project path.
    :param project_path: the path of a ai flow project.
    :return: a ProjectDesc object that contains the structure information of this project.
    """
    project_spec = ProjectDesc()
    project_path = os.path.abspath(project_path)
    project_spec.project_path = project_path
    project_path_obj = Path(project_path)
    project_spec.jar_dependencies = get_file_paths_from(str(project_path_obj / 'jar_dependencies'))
    project_spec.python_dependencies = get_file_paths_from(str(project_path_obj / 'python_codes'))
    project_spec.resources = get_file_paths_from(str(project_path_obj / 'resources'))
    if not os.path.exists(project_spec.get_absolute_temp_path()):
        os.makedirs(project_spec.get_absolute_temp_path())
    project_spec.project_config = _default_project_config
    return project_spec


def get_file_paths_from(dir: Text) -> List[Text]:
    """
    list all file paths inside a directory.

    :param dir: a directory path that need to list.
    :return: a string list of file paths.
    """
    if not os.path.exists(dir):
        print('{} does not exist.'.format(dir))
        return None
    file_paths = ["{}/{}".format(dir, x) for x in os.listdir(dir)]
    return file_paths


