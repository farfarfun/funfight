from typing import Text, Optional
from ai_flow.common.json_utils import Jsonable


class Channel(Jsonable):
    """ Node Object output"""

    def __init__(self,
                 node_id: Text,
                 port: Optional[int] = 0) -> None:
        """
        :param node_id: node identity id
        :param port: the index of output
        """
        super().__init__()
        self.node_id = node_id
        self.port = port


class NoneChannel(Channel):
    """ the node does not has output, identity the node"""

    def __init__(self, node_id: Text) -> None:
        super().__init__(node_id, None)
