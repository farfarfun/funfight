from typing import Text, List
from ai_flow.common.properties import ExecuteProperties
from ai_flow.meta.model_meta import ModelMeta, ModelVersionMeta
from ai_flow.meta.artifact_meta import ArtifactMeta
from ai_flow.executor.executor import BaseExecutor
from ai_flow.graph.ai_nodes.executable import ExecutableNode
from ai_flow.graph.channel import Channel, NoneChannel


class Pusher(ExecutableNode):

    def __init__(self,
                 model: ModelMeta,
                 executor: BaseExecutor,
                 model_version: ModelVersionMeta = None,
                 properties: ExecuteProperties = None,
                 name: Text = None,
                 instance_id: Text = None) -> None:
        super().__init__(executor=executor,
                         properties=properties,
                         name=name,
                         instance_id=instance_id,
                         output_num=0)
        self.model = model
        self.model_version = model_version

    def outputs(self) -> List[Channel]:
        return [NoneChannel(self.instance_id)]

