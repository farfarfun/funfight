from typing import Text, List
from ai_flow.graph.ai_node import AINode
from ai_flow.common.properties import ExecuteProperties
from ai_flow.executor.executor import BaseExecutor
from ai_flow.graph.channel import Channel, NoneChannel


class ExecutableNode(AINode):
    def __init__(self,
                 executor: BaseExecutor,
                 name: Text = None,
                 instance_id=None,
                 properties: ExecuteProperties = None,
                 output_num=1
                 ) -> None:
        super().__init__(properties=properties,
                         name=name,
                         instance_id=instance_id,
                         output_num=output_num)
        self.executor = executor

    def outputs(self) -> List[Channel]:
        if self.output_num > 0:
            result = []
            for i in range(self.output_num):
                result.append(Channel(node_id=self.instance_id, port=i))
            return result
        else:
            return [NoneChannel(self.instance_id)]
