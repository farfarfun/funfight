from ai_flow.common.json_utils import Jsonable
from ai_flow.graph.ai_node import AINode
from ai_flow.workflow.job_context import JobContext


class FunctionContext(Jsonable):
    def __init__(self,
                 node_spec: AINode,
                 job_context: JobContext) -> None:
        super().__init__()
        self.node_spec = node_spec
        self.job_context = job_context
