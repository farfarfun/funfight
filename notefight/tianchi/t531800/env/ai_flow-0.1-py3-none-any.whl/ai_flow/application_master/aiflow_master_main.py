import argparse
from ai_flow.application_master.master import AIFlowMaster


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True, help='master config file')
    args = parser.parse_args()
    print(args.config)
    config_file = args.config
    master = AIFlowMaster(
        config_file=config_file)
    master.start(is_block=True)
