import unittest

from ai_flow.common import json_utils
from ai_flow.graph.edge import DataEdge


class TestEdge(unittest.TestCase):

    def test_json(self):
        channel = DataEdge("a", 0)
        json_text = json_utils.dumps(channel)
        c2: DataEdge = json_utils.loads(json_text)
        self.assertEqual(channel.target_node_id, c2.target_node_id)
        self.assertEqual(channel.port, c2.port)


if __name__ == '__main__':
    unittest.main()
