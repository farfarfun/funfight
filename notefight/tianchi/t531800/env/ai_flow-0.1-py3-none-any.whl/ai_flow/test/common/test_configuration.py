import unittest

from ai_flow.common.configuration import AIFlowConfiguration
from ai_flow.common.path_util import get_file_dir


class TestConfiguration(unittest.TestCase):

    def test_dump_load_configuration(self):
        config = AIFlowConfiguration()
        test_yaml = get_file_dir(__file__) + "/test.yaml"
        config['a'] = 'a'
        config.dump_to_file(test_yaml)
        config.clear()
        config.load_from_file(test_yaml)
        self.assertEqual('a', config['a'])


if __name__ == '__main__':
    unittest.main()
