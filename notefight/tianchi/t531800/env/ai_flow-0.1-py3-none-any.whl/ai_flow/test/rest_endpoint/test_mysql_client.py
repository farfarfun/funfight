import unittest

import sqlalchemy

from ai_flow.rest_endpoint.service.client.aiflow_client import AIFlowClient
from ai_flow.rest_endpoint.service.server import AIFlowServer
from ai_flow.store.db.base_model import base
from ai_flow.test.rest_endpoint import test_client
from ai_flow.test.store.test_sqlalchemy_store import _get_store
from ai_flow.test.test_util import get_mysql_server_url

_PORT = '50051'


class TestAIFlowClientMySQL(test_client.TestAIFlowClientSqlite):

    @classmethod
    def setUpClass(cls) -> None:
        print("TestAIFlowClientMySQL setUpClass")
        db_server_url = get_mysql_server_url()
        cls.db_name = 'test_aiflow_client'
        cls.engine = sqlalchemy.create_engine(db_server_url)
        cls.engine.execute('CREATE DATABASE IF NOT EXISTS %s' % cls.db_name)
        cls.store_uri = '%s/%s' % (db_server_url, cls.db_name)
        cls.server = AIFlowServer(store_uri=cls.store_uri, port=_PORT)
        cls.server.run()
        test_client.client = AIFlowClient(server_uri='localhost:' + _PORT)
        test_client.client1 = AIFlowClient(server_uri='localhost:' + _PORT)
        test_client.client2 = AIFlowClient(server_uri='localhost:' + _PORT)

    @classmethod
    def tearDownClass(cls) -> None:
        test_client.client.stop_listen_notification()
        test_client.client1.stop_listen_notification()
        test_client.client2.stop_listen_notification()
        cls.server.stop()
        cls.engine.execute('DROP DATABASE IF EXISTS %s' % cls.db_name)

    def setUp(self) -> None:
        _get_store(self.store_uri)

    def tearDown(self) -> None:
        store = _get_store(self.store_uri)
        base.metadata.drop_all(store.db_engine)


if __name__ == '__main__':
    unittest.main()
