import asyncio
import os
import unittest
from abc import ABCMeta

import sqlalchemy

from ai_flow.notification.service.service import NotificationService
from ai_flow.rest_endpoint.protobuf.message_pb2 import Notification, Notifications
from ai_flow.rest_endpoint.protobuf.notification_service_pb2 import ListNotificationsRequest, \
    UpdateNotificationRequest
from ai_flow.rest_endpoint.service import stringValue, int32Value
from ai_flow.rest_endpoint.service.util import _parse_response
from ai_flow.store.db.base_model import base
from ai_flow.test.store.test_sqlalchemy_store import _get_store
from ai_flow.test.test_util import get_mysql_server_url

_SQLITE_DB_FILE = 'aiflow.db'
_SQLITE_DB_URI = '%s%s' % ('sqlite:///', _SQLITE_DB_FILE)


class TestNotificationServiceSqlite(unittest.TestCase):
    __metaclass__ = ABCMeta

    @classmethod
    def setUpClass(cls) -> None:
        if os.path.exists(_SQLITE_DB_FILE):
            os.remove(_SQLITE_DB_FILE)
        cls.notification_service = NotificationService(backend_store_uri=_SQLITE_DB_URI)

    @classmethod
    def tearDownClass(cls) -> None:
        os.remove(_SQLITE_DB_FILE)

    def setUp(self):
        self.store = _get_store(_SQLITE_DB_URI)

    def tearDown(self):
        base.metadata.drop_all(self.store.db_engine)

    async def _update_notification(self, k, v, s):
        await asyncio.sleep(s)
        update_notification_req = UpdateNotificationRequest(
            notification=Notification(key=stringValue(k), value=stringValue(v)))
        await self.notification_service.updateNotification(update_notification_req, None)

    async def _list_notifications(self, k, v, timeout):
        list_notification_req = ListNotificationsRequest(
            notification=Notification(key=stringValue(k), version=int32Value(v)),
            timeout_seconds=timeout)
        return await self.notification_service.listNotifications(list_notification_req, None)

    async def _gather_coroutine(self, k, v, version, timeout, sleep):
        return await asyncio.gather(self._list_notifications(k, version, timeout),
                                    self._update_notification(k, v, sleep),
                                    self._update_notification(k, v, sleep + 1),
                                    self._update_notification(k, v, sleep + 2))

    def testnotification_service(self):
        result = asyncio.get_event_loop().run_until_complete(
            self._gather_coroutine('test_ns_key', 'test_ns_value', 2, 5, 1))
        notifications = _parse_response(result[0], Notifications()).notifications
        self.assertEqual(len(notifications), 1)
        self.assertEqual(notifications[0].version.value, 3)

    def testnotification_service_with_timeout_waiting(self):
        result = asyncio.get_event_loop().run_until_complete(
            self._gather_coroutine('test_ns_wait_key', 'test_ns_wait_value', 0, 3, 3))
        notifications = _parse_response(result[0], Notifications()).notifications
        self.assertEqual(len(notifications), 0)


class TestNotificationServiceMySQL(TestNotificationServiceSqlite):

    @classmethod
    def setUpClass(cls) -> None:
        db_server_url = get_mysql_server_url()
        cls.db_name = 'test_aiflow_store'
        cls.engine = sqlalchemy.create_engine(db_server_url)
        cls.engine.execute('CREATE DATABASE IF NOT EXISTS %s' % cls.db_name)
        cls.store_uri = '%s/%s' % (db_server_url, cls.db_name)
        cls.notification_service = NotificationService(backend_store_uri=cls.store_uri)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.engine.execute('DROP DATABASE IF EXISTS %s' % cls.db_name)

    def setUp(self) -> None:
        self.store = _get_store(self.store_uri)

    def tearDown(self) -> None:
        store = _get_store(self.store_uri)
        base.metadata.drop_all(store.db_engine)


if __name__ == '__main__':
    unittest.main()
