from python_ai_flow.local_python_job import register_local_example_component
from python_ai_flow.kubernetes_python_job import register_k8s_example_component
from python_ai_flow.example_components.pandas.example import PandasIOExample
from python_ai_flow.example_components.numpy.example import NumpyIOExample
from python_ai_flow.example_components.rabbitmq.example import RabbitMQExample
from python_ai_flow.example_components.user_function.example import UDFExampleComponent


register_local_example_component("pandas", PandasIOExample)
register_local_example_component("numpy", NumpyIOExample)
register_local_example_component("rabbitmq", RabbitMQExample)
register_local_example_component("udf", UDFExampleComponent)

register_k8s_example_component("pandas", PandasIOExample)
register_k8s_example_component("numpy", NumpyIOExample)
register_k8s_example_component("rabbitmq", RabbitMQExample)
register_k8s_example_component("udf", UDFExampleComponent)

