import os
from ai_flow.api.configuration import set_project_config_file, project_config
from ai_flow.common import path_util


def get_project_path():
    return os.path.dirname(os.path.abspath(__file__))


def get_master_config_file():
    return os.path.dirname(os.path.abspath(__file__)) + "/master.yaml"


def get_project_config_file():
    return os.path.dirname(os.path.abspath(__file__)) + "/project.yaml"


def set_project_config(main_file):
    set_project_config_file(get_project_config_file())
    project_config()['entry_module_path'] = path_util.get_module_name(main_file)
