from typing import Text
from ai_flow.executor.executor import BaseExecutor, PythonObjectExecutor
from ai_flow.common.serialization_utils import serialize


class FlinkJavaExecutor(BaseExecutor):
    """
    Implementation of BaseExecutor. Represents the flink java executor.
    """
    def __init__(self, java_class: Text) -> None:
        """
        Construct of FlinkJavaExecutor.

        :param java_class: Class which execute the flink job.
        """
        super().__init__("flink_java")
        self.java_class: Text = java_class


class FlinkPythonExecutor(PythonObjectExecutor):
    """
    Implementation of BaseExecutor. Represents the flink python executor.
    """
    def __init__(self, python_object: object, node_id: Text = None) -> None:
        """
        Construct of FlinkPythonExecutor.

        :param python_object: Object includes the python executor.
        :param node_id: Id of node.
        """
        super().__init__(python_object=python_object, node_id=node_id)
        self.python_object: bytes = serialize(python_object)
