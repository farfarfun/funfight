from typing import Text, Dict, Any
from ai_flow.common.json_utils import dumps, Jsonable
from ai_flow.plugins.job_plugin import AISubGraph, ProjectDesc, JobContext, \
    AbstractJobConfig, AbstractJob, AbstractEngine
from ai_flow.meta.job_meta import ExecutionMode
from ai_flow.plugins.job_plugin import AbstractJobPlugin
from ai_flow.plugins.platform import AbstractPlatform
from flink_ai_flow.vvp.vvp_restful_api import default_flink_image_info, default_resources, default_flink_config, \
    default_logging, VVPRestful
from flink_ai_flow.flink_engine import FlinkEngine
from flink_ai_flow.flink_executor import FlinkJavaExecutor
from flink_ai_flow.vvp_platform import VVPJobHandler, VVPPlatform


class VVPJobConfig(AbstractJobConfig):
    @staticmethod
    def from_dict(data: Dict, config) -> object:
        super().from_dict(data, config)
        return config

    def __init__(self,
                 base_url: Text,
                 namespace: Text,
                 jar_path: Text,
                 deployment_name: Text,
                 main_args: Text = "",
                 token: Text = None,
                 flink_image_info=default_flink_image_info,
                 parallelism=1,
                 resources=default_resources,
                 flink_config=default_flink_config,
                 logging=default_logging,
                 properties: Dict[Text, Jsonable] = None) -> None:
        super().__init__('vvp', 'flink', properties)
        self.base_url = base_url
        self.namespace = namespace
        self.jar_path = jar_path
        self.deployment_name = deployment_name
        self.token = token
        self.flink_image_info = flink_image_info
        self.parallelism = parallelism
        self.resources = resources
        self.flink_config = flink_config
        self.logging = logging
        self.main_args = main_args


class VVPJob(AbstractJob):
    def __init__(self,
                 entry_class: Text,
                 job_context: JobContext,
                 job_config: VVPJobConfig) -> None:
        super().__init__(job_context, job_config)
        self.entry_class: Text = entry_class
        self.vvp_deployment_id: Text = None
        self.vvp_job_id: Text = None
        self.vvp_restful: VVPRestful \
            = VVPRestful(base_url=job_config.base_url, namespace=job_config.namespace, token=job_config.token)


class VVPFlinkJobPlugin(AbstractJobPlugin):

    def __init__(self) -> None:
        super().__init__()

    def generate(self, sub_graph: AISubGraph, project_desc: ProjectDesc) -> VVPJob:
        if sub_graph.config.exec_mode == ExecutionMode.BATCH:
            flink_context = JobContext(ExecutionMode.BATCH)
        else:
            flink_context = JobContext(ExecutionMode.STREAM)
        node = list(sub_graph.nodes.values())[0]
        executor: FlinkJavaExecutor = node.executor
        flink_context.project_config = project_desc.project_config
        job_config: VVPJobConfig = sub_graph.config
        job = VVPJob(entry_class=executor.java_class, job_context=flink_context, job_config=job_config)
        return job

    def generate_job_resource(self, job: VVPJob) -> None:
        """
        Generate flink job resource.

        :param job: Local flink job.
        """
        pass

    def submit_job(self, job: VVPJob) -> VVPJobHandler:
        vvp_config: VVPJobConfig = job.job_config
        jar_uri = job.vvp_restful.up_load_artifact(job.job_config.jar_path)
        dp_id, res = job.vvp_restful.create_deployment(name=job.job_config.deployment_name,
                                                       jar_uri=jar_uri,
                                                       entry_class=job.entry_class,
                                                       main_args=job.job_config.main_args,
                                                       flink_image_info=vvp_config.flink_image_info,
                                                       parallelism=vvp_config.parallelism,
                                                       resources=vvp_config.resources,
                                                       flink_config=vvp_config.flink_config,
                                                       logging=vvp_config.logging
                                                       )
        job.vvp_deployment_id = dp_id
        job.vvp_restful.start_deployment(job.vvp_deployment_id)
        job_id = job.vvp_restful.get_job_ids(dp_id)[0]
        job.vvp_job_id = job_id

        return VVPJobHandler(vvp_restful=job.vvp_restful,
                             vvp_job_id=job_id,
                             job_instance_id=job.instance_id,
                             job_uuid=job.uuid,
                             workflow_id=job.job_context.workflow_execution_id)

    def stop_job(self, job: VVPJob):
        job.vvp_restful.stop_deployment(job.vvp_deployment_id)

    def cleanup_job(self, job: AbstractJob):
        pass

    def platform(self) -> type(AbstractPlatform):
        return VVPPlatform

    def job_type(self) -> type(AbstractJob):
        return VVPJob

    def job_config_type(self) -> type(AbstractJobConfig):
        return VVPJobConfig

    def engine(self) -> type(AbstractEngine):
        return FlinkEngine
