from typing import Text
from ai_flow.plugins.engine import AbstractEngine


class FlinkEngine(AbstractEngine):
    @staticmethod
    def engine() -> Text:
        return 'flink'
